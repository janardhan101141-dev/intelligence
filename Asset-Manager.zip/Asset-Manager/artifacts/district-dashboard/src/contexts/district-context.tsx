import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type DistrictSlug = "guntur" | "krishna";

const STORAGE_KEY = "district-dashboard:selected-district";

const DISTRICT_LABELS: Record<DistrictSlug, string> = {
  guntur: "Guntur",
  krishna: "Krishna",
};

function readStoredDistrict(): DistrictSlug {
  if (typeof window === "undefined") return "guntur";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  return stored === "krishna" ? "krishna" : "guntur";
}

interface DistrictContextValue {
  district: DistrictSlug;
  districtLabel: string;
  setDistrict: (district: DistrictSlug) => void;
}

const DistrictContext = createContext<DistrictContextValue | undefined>(undefined);

export function DistrictProvider({ children }: { children: ReactNode }) {
  const [district, setDistrictState] = useState<DistrictSlug>(() => readStoredDistrict());

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, district);
  }, [district]);

  const setDistrict = (next: DistrictSlug) => setDistrictState(next);

  return (
    <DistrictContext.Provider value={{ district, districtLabel: DISTRICT_LABELS[district], setDistrict }}>
      {children}
    </DistrictContext.Provider>
  );
}

export function useDistrict() {
  const ctx = useContext(DistrictContext);
  if (!ctx) throw new Error("useDistrict must be used within a DistrictProvider");
  return ctx;
}

export const DISTRICT_OPTIONS: { value: DistrictSlug; label: string }[] = [
  { value: "guntur", label: "Guntur" },
  { value: "krishna", label: "Krishna" },
];
