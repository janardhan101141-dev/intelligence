import { Router } from "express";
import Parser from "rss-parser";
import { eq, desc } from "drizzle-orm";
import { cache } from "../lib/cache";
import { logger } from "../lib/logger";
import { resolveDistrict } from "../lib/district";

const router = Router();
const rssParser = new Parser({
  timeout: 10000,
  headers: { "User-Agent": "DistrictDashboard/1.0" },
});

const RSS_FEEDS = [
  { url: "https://www.thehindu.com/news/national/andhra-pradesh/feeder/default.rss", source: "The Hindu", category: "General" },
  { url: "https://feeds.feedburner.com/ndtvnews-india-news", source: "NDTV", category: "National" },
  { url: "https://timesofindia.indiatimes.com/rss.cms", source: "Times of India", category: "National" },
];

async function fetchLiveNews() {
  const cached = cache.get<object[]>("news");
  if (cached) return cached;

  const items: object[] = [];

  for (const feed of RSS_FEEDS) {
    try {
      const parsed = await rssParser.parseURL(feed.url);
      const feedItems = (parsed.items || []).slice(0, 6).map((item, idx) => ({
        id: `rss-${feed.source.toLowerCase().replace(/\s/g, "-")}-${idx}`,
        headline: item.title ?? "No title",
        summary: item.contentSnippet?.slice(0, 200) ?? item.summary?.slice(0, 200) ?? "",
        source: feed.source,
        category: feed.category,
        publishedAt: item.pubDate ? new Date(item.pubDate).toISOString() : new Date().toISOString(),
        url: item.link ?? undefined,
      }));
      items.push(...feedItems);
    } catch (err) {
      logger.warn({ err, url: feed.url }, "RSS feed fetch failed, skipping");
    }
  }

  if (items.length === 0) {
    logger.warn("All RSS feeds failed, returning DB news");
    return null;
  }

  items.sort((a: any, b: any) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
  const limited = items.slice(0, 20);
  cache.set("news", limited, 15 * 60 * 1000);
  return limited;
}

router.get("/news", async (req, res) => {
  try {
    const district = resolveDistrict(req);

    const { db } = await import("@workspace/db");
    const { newsTable } = await import("@workspace/db");
    const districtNews = await db
      .select()
      .from(newsTable)
      .where(eq(newsTable.district, district))
      .orderBy(desc(newsTable.publishedAt))
      .limit(20);

    const formattedDistrictNews = districtNews.map((n) => ({
      id: n.id,
      headline: n.headline,
      summary: n.summary,
      source: n.source,
      category: n.category,
      publishedAt: n.publishedAt.toISOString(),
      url: n.url ?? undefined,
    }));

    const liveNews = await fetchLiveNews();
    if (liveNews) {
      return res.json([...formattedDistrictNews, ...liveNews].slice(0, 20));
    }

    return res.json(formattedDistrictNews);
  } catch (err) {
    req.log.error({ err }, "Failed to get news");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
