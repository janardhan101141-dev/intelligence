import { useGetTransparency, getGetTransparencyQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { DataSource } from "@/components/data-source";
import { FileText, CheckCircle2, Clock4, AlertCircle, MessageSquare, Target } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const statusBadge: Record<string, string> = {
  completed: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  ongoing: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  pending: "bg-amber-500/15 text-amber-300 border-amber-500/30",
  delayed: "bg-red-500/15 text-red-300 border-red-500/30",
};

export default function Transparency() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetTransparency(params, { query: { queryKey: getGetTransparencyQueryKey(params) } });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING TRANSPARENCY DATA...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <FileText className="w-3.5 h-3.5" /> RTI Filed
            </div>
            <p className="text-2xl font-bold text-cyan-300 font-mono">{data.rti.totalFiled.toLocaleString("en-IN")}</p>
            <p className="text-[11px] text-muted-foreground mt-1">last 12 months</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <CheckCircle2 className="w-3.5 h-3.5" /> RTI Success Rate
            </div>
            <p className="text-2xl font-bold text-emerald-300 font-mono">{data.rti.successRate}%</p>
            <Progress value={data.rti.successRate} className="h-1 mt-2" />
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <Clock4 className="w-3.5 h-3.5" /> Avg Response
            </div>
            <p className="text-2xl font-bold text-amber-300 font-mono">{data.rti.avgResponseDays}<span className="text-sm">d</span></p>
            <p className="text-[11px] text-muted-foreground mt-1">target ≤ 30 days</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <Target className="w-3.5 h-3.5" /> Promises Met
            </div>
            <p className="text-2xl font-bold text-fuchsia-300 font-mono">{data.promiseSummary.overallCompletion}%</p>
            <p className="text-[11px] text-muted-foreground mt-1">{data.promiseSummary.completed}/{data.promiseSummary.total} fully done</p>
          </CardContent>
        </Card>
      </div>

      {/* RTI trend */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">RTI Requests — Filed vs Responded</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.rti.monthlyTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="rtiFiled" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="rtiResp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                />
                <Area type="monotone" dataKey="filed" name="Filed" stroke="#06b6d4" fill="url(#rtiFiled)" strokeWidth={2} />
                <Area type="monotone" dataKey="responded" name="Responded" stroke="#10b981" fill="url(#rtiResp)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Promise summary + grievances */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest">Promise Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-2 mb-4">
              <div className="rounded-lg bg-emerald-500/10 border border-emerald-500/30 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold text-emerald-300 font-mono">{data.promiseSummary.completed}</p>
              </div>
              <div className="rounded-lg bg-cyan-500/10 border border-cyan-500/30 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Ongoing</p>
                <p className="text-2xl font-bold text-cyan-300 font-mono">{data.promiseSummary.ongoing}</p>
              </div>
              <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-amber-300 font-mono">{data.promiseSummary.pending}</p>
              </div>
              <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Delayed</p>
                <p className="text-2xl font-bold text-red-300 font-mono">{data.promiseSummary.delayed}</p>
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-muted-foreground">Overall completion</span>
                <span className="text-fuchsia-300">{data.promiseSummary.overallCompletion}%</span>
              </div>
              <Progress value={data.promiseSummary.overallCompletion} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-primary" /> Grievance Resolution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-2 mb-4">
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Registered</p>
                <p className="text-lg font-bold text-cyan-300 font-mono">{data.grievances.registered.toLocaleString("en-IN")}</p>
              </div>
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Resolved</p>
                <p className="text-lg font-bold text-emerald-300 font-mono">{data.grievances.resolved.toLocaleString("en-IN")}</p>
              </div>
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Pending</p>
                <p className="text-lg font-bold text-amber-300 font-mono">{data.grievances.pending.toLocaleString("en-IN")}</p>
              </div>
            </div>
            <div className="mb-2">
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-muted-foreground">Resolution rate</span>
                <span className="text-emerald-300">{data.grievances.resolutionRate}%</span>
              </div>
              <Progress value={data.grievances.resolutionRate} className="h-2" />
            </div>
            <p className="text-[11px] text-muted-foreground font-mono">Avg resolution: {data.grievances.avgResolutionDays} days</p>
          </CardContent>
        </Card>
      </div>

      {/* Grievance categories */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Grievances by Category</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.grievances.byCategory} margin={{ top: 5, right: 10, left: 0, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="category" tick={{ fontSize: 10, fill: "hsl(var(--muted-foreground))" }} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                />
                <Bar dataKey="count" name="Total" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                <Bar dataKey="resolved" name="Resolved" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Promise list */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Government Promises Tracker</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {data.promises.map((p) => (
              <div key={p.id} className="rounded-lg border border-border/40 bg-background/50 p-4">
                <div className="flex flex-wrap items-start gap-2 mb-2">
                  <p className="font-semibold text-sm flex-1">{p.title}</p>
                  <Badge variant="outline" className="text-[10px] font-mono">{p.category}</Badge>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${statusBadge[p.status]}`}>{p.status}</span>
                </div>
                <div className="flex items-center gap-3 mb-2">
                  <Progress value={p.completion} className="h-1.5 flex-1" />
                  <span className="text-xs font-mono text-muted-foreground w-12 text-right">{p.completion}%</span>
                </div>
                <p className="text-[11px] text-muted-foreground font-mono flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Deadline: {p.deadline}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data.lastUpdated}
        sources={[
          { name: "Central Information Commission", url: "https://cic.gov.in", note: "RTI rules" },
          { name: "AP State Information Commission", url: "https://apic.gov.in", note: "RTI Andhra Pradesh" },
          { name: "Spandana Grievance Portal (AP)", url: "https://spandana.ap.gov.in", note: "Public grievances" },
          { name: "Promise Tracker (election manifestos)", note: "Compiled from CM/MLA pledges" },
        ]}
      />
    </div>
  );
}
