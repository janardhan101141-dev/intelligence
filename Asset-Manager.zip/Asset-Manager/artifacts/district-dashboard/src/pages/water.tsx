import {
  useGetWaterIntelligence,
  getGetWaterIntelligenceQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { DataSource } from "@/components/data-source";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Droplets, Truck, AlertTriangle, CheckCircle, Waves } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";

const statusColors: Record<string, string> = {
  normal: "text-emerald-400",
  shortage: "text-amber-400",
  disruption: "text-red-400",
};

const statusBg: Record<string, string> = {
  normal: "bg-emerald-500/10 border-emerald-500/30",
  shortage: "bg-amber-500/10 border-amber-500/30",
  disruption: "bg-red-500/10 border-red-500/30",
};

const statusDot: Record<string, string> = {
  normal: "bg-emerald-400",
  shortage: "bg-amber-400",
  disruption: "bg-red-400",
};

const sourceLabel: Record<string, string> = {
  borewell: "Borewell",
  canal: "Canal",
  municipal: "Municipal",
};

export default function Water() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetWaterIntelligence(params, {
    query: { queryKey: getGetWaterIntelligenceQueryKey(params) },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING WATER DATA...
      </div>
    );
  }

  const p = data?.prakasam;
  const damColor =
    (p?.percentFilled ?? 0) >= 70
      ? "text-emerald-400"
      : (p?.percentFilled ?? 0) >= 40
      ? "text-amber-400"
      : "text-red-400";
  const damBarColor =
    (p?.percentFilled ?? 0) >= 70 ? "bg-emerald-500" : (p?.percentFilled ?? 0) >= 40 ? "bg-amber-500" : "bg-red-500";

  const shortageCnt = data?.supplyAreas?.filter((a) => a.status !== "normal").length ?? 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-mono font-bold uppercase tracking-widest text-foreground">
          Water Intelligence
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Live supply status, dam levels, tanker deployment, and rainfall trends for Guntur District.
        </p>
      </div>

      {/* Summary strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          {
            label: "Dam Fill",
            value: `${p?.percentFilled ?? "--"}%`,
            sub: p?.status ?? "",
            color: damColor,
          },
          {
            label: "Storage",
            value: `${p?.storageTMC ?? "--"} TMC`,
            sub: `of ${p?.capacityTMC ?? "--"} TMC`,
            color: "text-cyan-400",
          },
          {
            label: "Areas with Shortage",
            value: shortageCnt,
            sub: `of ${data?.supplyAreas?.length ?? 0} areas`,
            color: shortageCnt > 0 ? "text-amber-400" : "text-emerald-400",
          },
          {
            label: "Tankers Deployed",
            value: data?.totalTankersDeployed ?? "--",
            sub: "active today",
            color: (data?.totalTankersDeployed ?? 0) > 0 ? "text-orange-400" : "text-emerald-400",
          },
        ].map((s) => (
          <Card key={s.label} className="bg-card border-border/50">
            <CardContent className="p-4 flex items-center gap-3">
              <div>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{s.label}</p>
                <p className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</p>
                <p className="text-[11px] text-muted-foreground">{s.sub}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Prakasam Barrage */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Waves className="w-4 h-4 text-cyan-400" />
            Prakasam Barrage — Live Levels
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            {[
              { label: "Current Level", value: `${p?.currentLevel ?? "--"} m`, sub: `FRL: ${p?.fullReservoirLevel} m` },
              { label: "Storage", value: `${p?.storageTMC ?? "--"} TMC`, sub: `Capacity: ${p?.capacityTMC} TMC` },
              { label: "Inflow", value: `${(p?.inflow ?? 0).toLocaleString()} cusecs`, sub: "current rate" },
              { label: "Outflow", value: `${(p?.outflow ?? 0).toLocaleString()} cusecs`, sub: "released today" },
            ].map((item) => (
              <div key={item.label} className="bg-background/50 rounded-lg p-3 border border-border/50">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{item.label}</p>
                <p className="text-xl font-bold font-mono text-cyan-400">{item.value}</p>
                <p className="text-[11px] text-muted-foreground">{item.sub}</p>
              </div>
            ))}
          </div>

          <div>
            <div className="flex justify-between mb-1 text-xs font-mono">
              <span className="text-muted-foreground">Fill Level</span>
              <span className={damColor}>{p?.percentFilled ?? 0}%</span>
            </div>
            <div className="h-4 bg-background rounded-full overflow-hidden border border-border/50">
              <div
                className={`h-full transition-all duration-700 ${damBarColor}`}
                style={{ width: `${p?.percentFilled ?? 0}%` }}
              />
            </div>
            <div className="flex justify-between text-[10px] font-mono text-muted-foreground mt-1">
              <span>0%</span>
              <span className="text-amber-400">40% (Low)</span>
              <span className="text-emerald-400">70% (Good)</span>
              <span>100% (FRL)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Area-wise supply status */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Droplets className="w-4 h-4 text-primary" />
            Area-wise Supply Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {(data?.supplyAreas ?? []).map((area) => (
              <div
                key={area.area}
                className={`rounded-lg border p-4 ${statusBg[area.status] ?? "bg-background border-border/40"}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold text-sm">{area.area}</p>
                    <p className="text-[11px] text-muted-foreground font-mono mt-0.5">
                      Source: {sourceLabel[area.source] ?? area.source}
                    </p>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${statusDot[area.status]}`} />
                    <span className={`text-[10px] font-mono uppercase tracking-widest ${statusColors[area.status]}`}>
                      {area.status}
                    </span>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider">Supply</p>
                    <p className="font-mono text-foreground">{area.supplyHours}h/day</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider">Last Supply</p>
                    <p className="font-mono text-foreground">{area.lastSupply}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-[10px] uppercase tracking-wider">Tankers</p>
                    <p className="font-mono text-foreground flex items-center gap-1">
                      {area.tankerDeployed ? (
                        <>
                          <Truck className="w-3 h-3 text-orange-400" />
                          <span className="text-orange-400">{area.tankerCount}</span>
                        </>
                      ) : (
                        <span className="text-muted-foreground">None</span>
                      )}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Rainfall vs Storage trend */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">
            Rainfall vs Water Storage — 12-Month Trend
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.rainfallTrend ?? []} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="rainfallGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.25} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="storageGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22d3ee" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#22d3ee" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis yAxisId="left" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} label={{ value: "mm", angle: -90, position: "insideLeft", fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} label={{ value: "TMC", angle: 90, position: "insideRight", fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  labelStyle={{ color: "hsl(var(--foreground))" }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Area yAxisId="left" type="monotone" dataKey="rainfall" name="Rainfall (mm)" stroke="#06b6d4" fill="url(#rainfallGrad)" strokeWidth={2} dot={false} />
                <Area yAxisId="right" type="monotone" dataKey="storage" name="Storage (TMC)" stroke="#22d3ee" fill="url(#storageGrad)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data?.lastUpdated}
        sources={[
          { name: "AP Water Resources Department", url: "https://wrd.ap.gov.in", note: "Prakasam Barrage levels" },
          { name: "India Meteorological Department", url: "https://imd.gov.in", note: "Rainfall data" },
          { name: "Guntur District Water Supply Authority", note: "Area supply status" },
          { name: "Central Water Commission", url: "https://cwc.gov.in", note: "Dam storage standards" },
        ]}
      />
    </div>
  );
}
