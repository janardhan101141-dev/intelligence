import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const DISTRICT_CONFIG: Record<
  string,
  {
    gdpCroreBase: number;
    revenueCroreBase: number;
    expenditureCroreBase: number;
    debtCroreBase: number;
    gdpGrowth: number;
    population: number;
    industries: { name: string; sector: string; units: number; employees: number; revenueCrore: number }[];
  }
> = {
  guntur: {
    gdpCroreBase: 138400,
    revenueCroreBase: 9420,
    expenditureCroreBase: 10180,
    debtCroreBase: 28960,
    gdpGrowth: 7.8,
    population: 5823000,
    industries: [
      { name: "Guntur Chilli Cluster", sector: "Agro Processing", units: 1240, employees: 28400, revenueCrore: 4280 },
      { name: "Cotton Ginning Mills", sector: "Textile", units: 480, employees: 12200, revenueCrore: 1860 },
      { name: "Tobacco Auction & Processing", sector: "Agro Processing", units: 220, employees: 8400, revenueCrore: 1240 },
      { name: "Mangalagiri Handloom", sector: "Textile", units: 3200, employees: 9800, revenueCrore: 320 },
      { name: "Cement & Lime (Piduguralla)", sector: "Manufacturing", units: 86, employees: 4800, revenueCrore: 1480 },
      { name: "Tenali Rice Mills", sector: "Food Processing", units: 360, employees: 5600, revenueCrore: 880 },
      { name: "Shrimp / Aquaculture (Coastal)", sector: "Marine", units: 2840, employees: 18400, revenueCrore: 2160 },
      { name: "Brick Kilns", sector: "Construction Materials", units: 920, employees: 9200, revenueCrore: 480 },
    ],
  },
  krishna: {
    gdpCroreBase: 124200,
    revenueCroreBase: 8640,
    expenditureCroreBase: 9280,
    debtCroreBase: 24380,
    gdpGrowth: 8.4,
    population: 4517000,
    industries: [
      { name: "Vijayawada Business & Trade Hub", sector: "Commerce", units: 4200, employees: 42000, revenueCrore: 6840 },
      { name: "Machilipatnam Port & Logistics", sector: "Maritime", units: 180, employees: 9800, revenueCrore: 2680 },
      { name: "Gudivada Textile Cluster", sector: "Textile", units: 2600, employees: 14200, revenueCrore: 960 },
      { name: "Vuyyuru Sugar Mills", sector: "Agro Processing", units: 64, employees: 5600, revenueCrore: 1180 },
      { name: "Jaggayyapeta Cement & Limestone", sector: "Manufacturing", units: 42, employees: 3800, revenueCrore: 1640 },
      { name: "Kaikaluru Aquaculture Belt", sector: "Marine", units: 3400, employees: 22600, revenueCrore: 3120 },
      { name: "Nuzvid Mango Processing", sector: "Agro Processing", units: 380, employees: 6200, revenueCrore: 740 },
      { name: "Gannavaram Airport & Aviation Services", sector: "Aviation", units: 28, employees: 2400, revenueCrore: 560 },
    ],
  },
};

router.get("/economy", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `economy-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const cfg = DISTRICT_CONFIG[slug];
  const seed = new Date().getDate();
  const gdpCrore = cfg.gdpCroreBase + seed * 22;
  const revenueCrore = cfg.revenueCroreBase + seed * 4;
  const expenditureCrore = cfg.expenditureCroreBase + seed * 3;
  const fiscalDeficitCrore = expenditureCrore - revenueCrore;
  const debtCrore = cfg.debtCroreBase + seed * 18;

  const months = ["May 25", "Jun 25", "Jul 25", "Aug 25", "Sep 25", "Oct 25", "Nov 25", "Dec 25", "Jan 26", "Feb 26", "Mar 26", "Apr 26"];
  const revenueBase = Math.round(cfg.revenueCroreBase / 13);
  const expenditureBase = Math.round(cfg.expenditureCroreBase / 13);
  const revenueExpenditureTrend = months.map((month, i) => ({
    month,
    revenue: Math.round(revenueBase + i * 24 + (seed % 12) * 2),
    expenditure: Math.round(expenditureBase + i * 26 + (seed % 14) * 2),
  }));

  const debtStart = Math.round(cfg.debtCroreBase * 0.63);
  const debtTrend = [
    { year: 2019, debt: debtStart },
    { year: 2020, debt: Math.round(debtStart * 1.14) },
    { year: 2021, debt: Math.round(debtStart * 1.26) },
    { year: 2022, debt: Math.round(debtStart * 1.35) },
    { year: 2023, debt: Math.round(debtStart * 1.43) },
    { year: 2024, debt: Math.round(debtStart * 1.5) },
    { year: 2025, debt: Math.round(debtStart * 1.56) },
    { year: 2026, debt: debtCrore },
  ];

  const revenueSources =
    slug === "krishna"
      ? [
          { source: "GST", amount: 3420 },
          { source: "Port & Maritime Cess", amount: 980 },
          { source: "Stamps & Registration", amount: 1420 },
          { source: "Excise & Liquor", amount: 1280 },
          { source: "Motor Vehicle Tax", amount: 640 },
          { source: "Land Revenue", amount: 380 },
          { source: "Other Tax", amount: 520 },
        ]
      : [
          { source: "GST", amount: 3680 },
          { source: "Stamps & Registration", amount: 1240 },
          { source: "Excise & Liquor", amount: 1580 },
          { source: "Motor Vehicle Tax", amount: 720 },
          { source: "Land Revenue", amount: 460 },
          { source: "Mining Royalty", amount: 380 },
          { source: "Other Tax", amount: 1360 },
        ];

  const trafficViolations = (slug === "krishna" ? 7180 : 8240) + seed * 80;
  const trafficRevenue = {
    monthlyCrore: Math.round(((trafficViolations * 850) / 1e7) * 10) / 10,
    yearlyCrore: Math.round(((trafficViolations * 850 * 12) / 1e7) * 10) / 10,
    violations: trafficViolations,
    collectionRate: slug === "krishna" ? 81.2 : 78.4,
  };

  const data = {
    gdpCrore,
    gdpGrowth: cfg.gdpGrowth,
    perCapitaIncome: Math.round((gdpCrore * 1e7) / cfg.population),
    revenueCrore,
    expenditureCrore,
    fiscalDeficitCrore,
    debtCrore,
    debtToGdp: Math.round((debtCrore / gdpCrore) * 1000) / 10,
    revenueExpenditureTrend,
    debtTrend,
    revenueSources,
    trafficRevenue,
    industries: cfg.industries,
    lastUpdated: new Date().toISOString(),
  };

  cache.set(cacheKey, data, 30 * 60 * 1000);
  return res.json(data);
});

export default router;
