# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite, Tailwind CSS, Recharts, TanStack Query

## Artifacts

### district-dashboard (React + Vite, previewPath: /)
District Intelligence Dashboard for Guntur, Andhra Pradesh. A civic command center featuring:
- District overview with population, area, literacy, mandals stats
- District Health Score (computed 0-100) with 10 sub-metrics radar chart
- Live alerts with severity color-coding (critical, warning, medium, info)
- Weather data card
- Dam water levels with progress bars
- Agricultural mandi prices with change indicators (Recharts)
- Governance & Finance with budget utilization charts
- News feed from district sources
- Mandals grid with population/area/tags
- Citizen services grid (12 services)

### api-server (Express, previewPath: /api)
Backend API serving all dashboard data. Routes:
- GET /api/district — district overview
- GET /api/district/health-score — computed health score
- GET /api/district/mandals — all mandals
- GET /api/district/services — citizen services
- GET /api/district/summary — dashboard summary
- GET /api/weather — current weather
- GET /api/weather/dam-levels — dam levels
- GET /api/alerts — active alerts
- GET /api/mandi — mandi prices
- GET /api/news — news feed
- GET /api/governance — governance & finance

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Database Tables
- `districts` — district overview data
- `mandals` — mandal/area records
- `alerts` — active district alerts
- `news` — news articles
- `mandi_prices` — agricultural market prices
- `citizen_services` — citizen service directory

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
