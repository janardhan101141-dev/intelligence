import { AppLayout } from "@/components/layout";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { DistrictProvider } from "@/contexts/district-context";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Mandals from "@/pages/mandals";
import Services from "@/pages/services";
import Governance from "@/pages/governance";
import News from "@/pages/news";
import Mandi from "@/pages/mandi";
import Water from "@/pages/water";
import Housing from "@/pages/housing";
import Power from "@/pages/power";
import Health from "@/pages/health";
import Police from "@/pages/police";
import AQI from "@/pages/aqi";
import Demographics from "@/pages/demographics";
import Transparency from "@/pages/transparency";
import Infrastructure from "@/pages/infrastructure";
import Economy from "@/pages/economy";
import Comparison from "@/pages/comparison";
import Traffic from "@/pages/traffic";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: true,
      staleTime: 1000 * 60 * 2,
      refetchInterval: 1000 * 60 * 5,
    },
  },
});

function Router() {
  return (
    <AppLayout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/mandals" component={Mandals} />
        <Route path="/services" component={Services} />
        <Route path="/governance" component={Governance} />
        <Route path="/news" component={News} />
        <Route path="/mandi" component={Mandi} />
        <Route path="/water" component={Water} />
        <Route path="/housing" component={Housing} />
        <Route path="/power" component={Power} />
        <Route path="/health" component={Health} />
        <Route path="/police" component={Police} />
        <Route path="/aqi" component={AQI} />
        <Route path="/demographics" component={Demographics} />
        <Route path="/transparency" component={Transparency} />
        <Route path="/infrastructure" component={Infrastructure} />
        <Route path="/economy" component={Economy} />
        <Route path="/comparison" component={Comparison} />
        <Route path="/traffic" component={Traffic} />
        <Route component={NotFound} />
      </Switch>
    </AppLayout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <DistrictProvider>
        <TooltipProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Router />
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </DistrictProvider>
    </QueryClientProvider>
  );
}

export default App;
