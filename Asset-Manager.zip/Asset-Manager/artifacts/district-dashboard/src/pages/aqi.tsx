import {
  useGetAQI,
  getGetAQIQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Wind, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { DataSource } from "@/components/data-source";
import { useDistrict } from "@/contexts/district-context";

const categoryInfo: Record<string, { label: string; emoji: string }> = {
  Good: { label: "No health concern", emoji: "Good" },
  Satisfactory: { label: "Acceptable quality", emoji: "Satisfactory" },
  Moderate: { label: "May affect sensitive groups", emoji: "Moderate" },
  Poor: { label: "Health effects for all", emoji: "Poor" },
  "Very Poor": { label: "Serious health effects", emoji: "Very Poor" },
  Severe: { label: "Emergency conditions", emoji: "Severe" },
};

const pollutants = [
  { key: "pm25" as const, label: "PM2.5", unit: "µg/m³", safe: 60, concern: 90 },
  { key: "pm10" as const, label: "PM10", unit: "µg/m³", safe: 100, concern: 150 },
  { key: "no2" as const, label: "NO2", unit: "µg/m³", safe: 40, concern: 80 },
  { key: "so2" as const, label: "SO2", unit: "µg/m³", safe: 20, concern: 80 },
  { key: "co" as const, label: "CO", unit: "mg/m³", safe: 2, concern: 10 },
  { key: "o3" as const, label: "O3", unit: "µg/m³", safe: 50, concern: 100 },
];

export default function AQI() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetAQI(params, {
    query: { queryKey: getGetAQIQueryKey(params) },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING AIR QUALITY DATA...
      </div>
    );
  }

  const cat = data?.category ?? "Moderate";
  const info = categoryInfo[cat] ?? { label: "Unknown", emoji: cat };
  const aqi = data?.aqi ?? 0;

  // AQI gauge percent (0-500 scale, capped at 300 for display)
  const gaugePercent = Math.min(100, (aqi / 300) * 100);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold uppercase tracking-widest text-foreground">
          Air Quality Index
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Real-time AQI, pollutant levels, and health recommendations for Guntur District.
        </p>
      </div>

      {/* Big AQI display */}
      <Card className="bg-card border-border/50 overflow-hidden">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Circular gauge */}
            <div className="relative w-44 h-44 shrink-0">
              <svg viewBox="0 0 120 120" className="w-full h-full -rotate-90">
                <circle cx="60" cy="60" r="50" fill="none" stroke="hsl(var(--border))" strokeWidth="10" />
                <circle
                  cx="60"
                  cy="60"
                  r="50"
                  fill="none"
                  stroke={data?.color ?? "#eab308"}
                  strokeWidth="10"
                  strokeLinecap="round"
                  strokeDasharray={`${(gaugePercent / 100) * 314.16} 314.16`}
                  className="transition-all duration-1000"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="text-5xl font-bold font-mono" style={{ color: data?.color ?? "#eab308" }}>
                  {aqi}
                </p>
                <p className="text-xs font-mono text-muted-foreground mt-1">AQI</p>
              </div>
            </div>

            {/* Category and info */}
            <div className="flex-1 text-center md:text-left">
              <p className="text-2xl font-bold font-mono" style={{ color: data?.color ?? "#eab308" }}>
                {cat}
              </p>
              <p className="text-sm text-muted-foreground mt-1">{info.label}</p>
              <p className="text-xs font-mono text-muted-foreground mt-1">
                Dominant Pollutant: <span className="text-foreground">{data?.dominantPollutant}</span>
              </p>
              <p className="text-xs text-muted-foreground mt-1">{data?.station}</p>
              <p className="text-[11px] text-muted-foreground mt-1">
                Updated: {data?.lastUpdated ? new Date(data.lastUpdated).toLocaleTimeString() : "--"}
              </p>
            </div>

            {/* AQI scale legend */}
            <div className="shrink-0 space-y-1">
              {[
                { label: "Good", range: "0–50", color: "#22c55e" },
                { label: "Satisfactory", range: "51–100", color: "#84cc16" },
                { label: "Moderate", range: "101–200", color: "#eab308" },
                { label: "Poor", range: "201–300", color: "#f97316" },
                { label: "Very Poor", range: "301–400", color: "#ef4444" },
                { label: "Severe", range: "401+", color: "#7c3aed" },
              ].map((s) => (
                <div key={s.label} className="flex items-center gap-2 text-xs">
                  <span className="w-3 h-3 rounded-sm shrink-0" style={{ backgroundColor: s.color }} />
                  <span className="text-muted-foreground w-20">{s.label}</span>
                  <span className="font-mono text-muted-foreground">{s.range}</span>
                  {s.label === cat && <span className="text-[10px] font-mono text-foreground">← Now</span>}
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pollutant breakdown */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Wind className="w-4 h-4 text-primary" />
            Pollutant Levels
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {pollutants.map((p) => {
              const val = data ? data[p.key] : 0;
              const barPct = Math.min(100, (val / (p.concern * 1.5)) * 100);
              const barColor =
                val <= p.safe ? "bg-emerald-500" : val <= p.concern ? "bg-amber-500" : "bg-red-500";
              const textColor =
                val <= p.safe ? "text-emerald-400" : val <= p.concern ? "text-amber-400" : "text-red-400";
              return (
                <div key={p.key} className="bg-background/50 rounded-lg p-4 border border-border/40">
                  <div className="flex justify-between items-baseline mb-2">
                    <p className="font-mono text-sm font-semibold">{p.label}</p>
                    <div className="text-right">
                      <span className={`text-lg font-bold font-mono ${textColor}`}>{val}</span>
                      <span className="text-xs text-muted-foreground ml-1">{p.unit}</span>
                    </div>
                  </div>
                  <div className="h-2 bg-background rounded-full overflow-hidden border border-border/50">
                    <div className={`h-full transition-all duration-700 ${barColor}`} style={{ width: `${barPct}%` }} />
                  </div>
                  <div className="flex justify-between text-[10px] font-mono text-muted-foreground mt-1">
                    <span>0</span>
                    <span className="text-emerald-400">Safe &lt;{p.safe}</span>
                    <span className="text-amber-400">High &gt;{p.concern}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Health recommendations */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest flex items-center gap-2">
            <Info className="w-4 h-4 text-primary" />
            Health Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {(data?.healthRecommendations ?? []).map((rec, i) => (
              <div key={i} className="flex items-start gap-3 p-3 bg-background/50 rounded-lg border border-border/40">
                <CheckCircle className="w-4 h-4 mt-0.5 shrink-0" style={{ color: data?.color ?? "#eab308" }} />
                <p className="text-sm text-foreground">{rec}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data?.lastUpdated}
        sources={[
          { name: "APPCB Monitoring Station", url: "https://appcb.ap.gov.in", note: "Guntur AQI readings" },
          { name: "CPCB National Air Quality Index", url: "https://cpcb.nic.in", note: "AQI categories & standards" },
          { name: "SAMEER App (MoEF&CC)", url: "https://app.cpcbccr.com", note: "PM2.5, PM10, NO2, SO2 thresholds" },
        ]}
      />
    </div>
  );
}
