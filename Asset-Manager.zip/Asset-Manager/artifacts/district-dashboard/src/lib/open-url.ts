export function openUrl(url: string) {
  try {
    (window.top ?? window).open(url, "_blank", "noopener,noreferrer");
  } catch {
    window.open(url, "_blank", "noopener,noreferrer");
  }
}
