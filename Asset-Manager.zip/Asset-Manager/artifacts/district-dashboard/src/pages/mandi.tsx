import { useGetMandiPrices, getGetMandiPricesQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TrendingUp, TrendingDown, ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useDistrict } from "@/contexts/district-context";

export default function Mandi() {
  const { district } = useDistrict();
  const params = { district };
  const { data: prices } = useGetMandiPrices(params, { query: { queryKey: getGetMandiPricesQueryKey(params) } });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground font-mono uppercase tracking-tight">Agricultural Market (Mandi) Prices</h1>
          <p className="text-muted-foreground mt-1">Live crop prices across district markets.</p>
        </div>
      </div>

      <Card className="bg-card border-border overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-sidebar">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="font-mono text-muted-foreground uppercase text-xs">Commodity</TableHead>
                <TableHead className="font-mono text-muted-foreground uppercase text-xs">Variety</TableHead>
                <TableHead className="font-mono text-muted-foreground uppercase text-xs">Market</TableHead>
                <TableHead className="font-mono text-muted-foreground uppercase text-xs text-right">Price</TableHead>
                <TableHead className="font-mono text-muted-foreground uppercase text-xs text-right">Change</TableHead>
                <TableHead className="font-mono text-muted-foreground uppercase text-xs text-right">Last Updated</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {prices?.map((item) => (
                <TableRow key={item.id} className="border-border hover:bg-accent/10">
                  <TableCell className="font-medium">{item.crop}</TableCell>
                  <TableCell className="text-muted-foreground">{item.variety}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="bg-sidebar font-mono font-normal">
                      {item.market}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right font-mono font-bold text-primary">
                    ₹{item.price}<span className="text-xs text-muted-foreground font-normal ml-1">/{item.unit}</span>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className={`inline-flex items-center justify-end gap-1.5 px-2 py-1 rounded text-xs font-mono font-medium ${
                      item.change >= 0 ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500"
                    }`}>
                      {item.change >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {item.change > 0 ? "+" : ""}{item.change} ({(item.changePercent).toFixed(1)}%)
                    </div>
                  </TableCell>
                  <TableCell className="text-right text-xs text-muted-foreground font-mono">
                    {new Date(item.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}
