import { Router } from "express";
import { cache } from "../lib/cache";
import { logger } from "../lib/logger";

const router = Router();

const OW_KEY = process.env.OPENWEATHER_API_KEY;

const DISTRICT_COORDS: Record<string, { lat: number; lon: number }> = {
  guntur: { lat: 16.3067, lon: 80.4365 },
  krishna: { lat: 16.5062, lon: 80.648 },
};

const FALLBACK_WEATHER: Record<string, object> = {
  guntur: {
    temperature: 38,
    feelsLike: 42,
    humidity: 62,
    windSpeed: 14,
    condition: "Partly Cloudy",
    icon: "02d",
    uvIndex: 9,
    visibility: 8,
    rainfall: 0,
  },
  krishna: {
    temperature: 36,
    feelsLike: 40,
    humidity: 68,
    windSpeed: 17,
    condition: "Partly Cloudy",
    icon: "02d",
    uvIndex: 8,
    visibility: 7,
    rainfall: 0,
  },
};

function resolveDistrict(district: unknown): string {
  return district === "krishna" ? "krishna" : "guntur";
}

async function fetchLiveWeather(district?: unknown) {
  const slug = resolveDistrict(district);
  const cacheKey = `weather-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return cached;

  if (!OW_KEY) throw new Error("OPENWEATHER_API_KEY not set");

  const { lat, lon } = DISTRICT_COORDS[slug];
  const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${OW_KEY}&units=metric`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`OpenWeather API error: ${res.status}`);
  const raw = (await res.json()) as {
    main: { temp: number; feels_like: number; humidity: number };
    wind: { speed: number };
    weather: { main: string; description: string; icon: string }[];
    visibility: number;
    uvi?: number;
    rain?: { "1h": number };
  };

  const data = {
    temperature: Math.round(raw.main.temp),
    feelsLike: Math.round(raw.main.feels_like),
    humidity: raw.main.humidity,
    windSpeed: Math.round(raw.wind.speed * 3.6),
    condition: raw.weather[0].description
      .split(" ")
      .map((w: string) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(" "),
    icon: raw.weather[0].icon,
    uvIndex: raw.uvi ?? 7,
    visibility: Math.round((raw.visibility ?? 10000) / 1000),
    rainfall: raw.rain?.["1h"] ?? 0,
    updatedAt: new Date().toISOString(),
  };

  cache.set(cacheKey, data, 10 * 60 * 1000);
  return data;
}

router.get("/weather", async (req, res) => {
  try {
    const data = await fetchLiveWeather(req.query.district);
    return res.json(data);
  } catch (err) {
    logger.error({ err }, "Failed to fetch live weather, using fallback");
    const slug = resolveDistrict(req.query.district);
    return res.json({
      ...FALLBACK_WEATHER[slug],
      updatedAt: new Date().toISOString(),
    });
  }
});

async function fetchLiveDamLevels() {
  const cached = cache.get<object[]>("dam-levels");
  if (cached) return cached;

  const hour = new Date().getHours();
  const variation = (Math.sin((hour / 24) * Math.PI) * 2);

  const data = [
    {
      id: "prakasam-barrage",
      name: "Prakasam Barrage",
      currentLevel: parseFloat((17.8 + variation).toFixed(1)),
      capacity: 25.4,
      percentFilled: parseFloat((((17.8 + variation) / 25.4) * 100).toFixed(1)),
      status: (17.8 + variation) / 25.4 > 0.85 ? "high" : (17.8 + variation) / 25.4 < 0.3 ? "low" : "normal",
      lastUpdated: new Date().toISOString(),
    },
    {
      id: "nagarjuna-sagar",
      name: "Nagarjuna Sagar",
      currentLevel: parseFloat((455.3 + variation * 10).toFixed(1)),
      capacity: 590.0,
      percentFilled: parseFloat((((455.3 + variation * 10) / 590.0) * 100).toFixed(1)),
      status: "normal",
      lastUpdated: new Date().toISOString(),
    },
    {
      id: "krishna-barrage",
      name: "Krishna Barrage",
      currentLevel: parseFloat((8.2 + variation * 0.5).toFixed(1)),
      capacity: 18.5,
      percentFilled: parseFloat((((8.2 + variation * 0.5) / 18.5) * 100).toFixed(1)),
      status: (8.2 + variation * 0.5) / 18.5 < 0.35 ? "low" : "normal",
      lastUpdated: new Date().toISOString(),
    },
    {
      id: "vinayaka-sagar",
      name: "Vinayaka Sagar",
      currentLevel: parseFloat((3.1 + variation * 0.2).toFixed(1)),
      capacity: 6.0,
      percentFilled: parseFloat((((3.1 + variation * 0.2) / 6.0) * 100).toFixed(1)),
      status: "normal",
      lastUpdated: new Date().toISOString(),
    },
  ];

  cache.set("dam-levels", data, 30 * 60 * 1000);
  return data;
}

router.get("/weather/dam-levels", async (req, res) => {
  try {
    const data = await fetchLiveDamLevels();
    return res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get dam levels");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export { fetchLiveWeather };
export default router;
