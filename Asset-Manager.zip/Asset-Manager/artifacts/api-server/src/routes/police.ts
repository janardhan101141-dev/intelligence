import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const GUNTUR_STATIONS = [
  { id: "ps-001", name: "Guntur I Town Police Station", address: "Brodipet Main Road, Guntur – 522002", phone: "0863-2224233", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Brodipet, Kothapet, Arundelpet", mapUrl: "https://maps.google.com/?q=Guntur+Town+Police+Station" },
  { id: "ps-002", name: "Guntur II Town Police Station", address: "Collectorate Road, Guntur – 522001", phone: "0863-2235466", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Collector Office area, Old Town, Naaz Centre", mapUrl: "https://maps.google.com/?q=Guntur+II+Town+Police+Station" },
  { id: "ps-003", name: "Mangalagiri Police Station", address: "NH-16, Mangalagiri – 522503", phone: "0863-2461100", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Mangalagiri, Thullur, Undavalli", mapUrl: "https://maps.google.com/?q=Mangalagiri+Police+Station" },
  { id: "ps-004", name: "Tenali Police Station", address: "Station Road, Tenali – 522201", phone: "08644-222233", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Tenali Urban, Vatticherukuru", mapUrl: "https://maps.google.com/?q=Tenali+Police+Station" },
  { id: "ps-005", name: "Narasaraopet Police Station", address: "Court Centre, Narasaraopet – 522601", phone: "08647-230033", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Narasaraopet Urban, Vinukonda Road", mapUrl: "https://maps.google.com/?q=Narasaraopet+Police+Station" },
  { id: "ps-006", name: "Bapatla Police Station", address: "RTC Road, Bapatla – 522101", phone: "08643-222100", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Bapatla Urban, Chirala Road Belt", mapUrl: "https://maps.google.com/?q=Bapatla+Police+Station" },
  { id: "ps-007", name: "Sattenapalle Police Station", address: "Bus Stand Road, Sattenapalle – 522403", phone: "08647-255033", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Sattenapalle, Piduguralla area", mapUrl: "https://maps.google.com/?q=Sattenapalle+Police+Station" },
  { id: "ps-008", name: "Repalle Police Station", address: "Coastal Highway, Repalle – 522265", phone: "08648-222044", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Repalle, Nizampatnam coastal belt", mapUrl: "https://maps.google.com/?q=Repalle+Police+Station" },
];

const KRISHNA_STATIONS = [
  { id: "kr-ps-001", name: "Vijayawada I Town (Governorpet) Police Station", address: "Governorpet, Vijayawada – 520002", phone: "0866-2571100", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Governorpet, Suryaraopet, MG Road", mapUrl: "https://maps.google.com/?q=Governorpet+Police+Station+Vijayawada" },
  { id: "kr-ps-002", name: "Vijayawada II Town (Patamata) Police Station", address: "Patamata, Vijayawada – 520010", phone: "0866-2470233", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Patamata, Bhavanipuram, Gunadala", mapUrl: "https://maps.google.com/?q=Patamata+Police+Station+Vijayawada" },
  { id: "kr-ps-003", name: "Machilipatnam Town Police Station", address: "Bandar Road, Machilipatnam – 521001", phone: "08672-222233", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Machilipatnam Town, Bandar Port area", mapUrl: "https://maps.google.com/?q=Machilipatnam+Town+Police+Station" },
  { id: "kr-ps-004", name: "Gudivada Police Station", address: "Station Road, Gudivada – 521301", phone: "08674-243100", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Gudivada Urban, Pedaparupudi", mapUrl: "https://maps.google.com/?q=Gudivada+Police+Station" },
  { id: "kr-ps-005", name: "Nuzvid Police Station", address: "College Road, Nuzvid – 521201", phone: "08656-232033", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Nuzvid Urban, Mylavaram Road", mapUrl: "https://maps.google.com/?q=Nuzvid+Police+Station" },
  { id: "kr-ps-006", name: "Gannavaram Police Station", address: "Airport Road, Gannavaram – 521101", phone: "0866-2857100", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Gannavaram, Airport area", mapUrl: "https://maps.google.com/?q=Gannavaram+Police+Station" },
  { id: "kr-ps-007", name: "Jaggayyapeta Police Station", address: "NH-65, Jaggayyapeta – 521175", phone: "08659-222033", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Jaggayyapeta, Cement Belt area", mapUrl: "https://maps.google.com/?q=Jaggayyapeta+Police+Station" },
  { id: "kr-ps-008", name: "Avanigadda Police Station", address: "Coastal Highway, Avanigadda – 521121", phone: "08671-222044", inCharge: "Sub-Inspector (I/C)", jurisdiction: "Avanigadda, Nagayalanka coastal belt", mapUrl: "https://maps.google.com/?q=Avanigadda+Police+Station" },
];

router.get("/police", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `police-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const stations = slug === "krishna" ? KRISHNA_STATIONS : GUNTUR_STATIONS;
  const populationLakh = slug === "krishna" ? 45.17 : 58.23;

  const now = new Date();
  const month = now.getMonth();
  const dayOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
  const seed = dayOfYear % 20;

  const totalBase = slug === "krishna" ? 690 : 820;
  const totalThisMonth = totalBase + seed * 12;
  const categories =
    slug === "krishna"
      ? [
          { category: "Property Theft", count: 172 + seed * 4, change: -6 + (seed % 5) },
          { category: "Assault & Disputes", count: 138 + seed * 2, change: 2 + (seed % 4) },
          { category: "Cybercrime", count: 112 + seed * 3, change: 26 + (seed % 8) },
          { category: "Traffic Violations (FIR)", count: 158 + seed * 2, change: -4 + (seed % 3) },
          { category: "Domestic Violence", count: 58 + seed, change: -10 + (seed % 5) },
          { category: "NDPS / Drug Cases", count: 38 + (seed % 5), change: 6 + (seed % 4) },
          { category: "Cheating & Fraud", count: 64 + seed, change: 18 + (seed % 6) },
          { category: "Other IPC Offences", count: 22 + (seed % 8), change: -1 + (seed % 3) },
        ]
      : [
          { category: "Property Theft", count: 218 + seed * 4, change: -8 + (seed % 5) },
          { category: "Assault & Disputes", count: 164 + seed * 2, change: 3 + (seed % 4) },
          { category: "Cybercrime", count: 98 + seed * 3, change: 22 + (seed % 8) },
          { category: "Traffic Violations (FIR)", count: 142 + seed * 2, change: -5 + (seed % 3) },
          { category: "Domestic Violence", count: 72 + seed, change: -12 + (seed % 5) },
          { category: "NDPS / Drug Cases", count: 44 + (seed % 5), change: 8 + (seed % 4) },
          { category: "Cheating & Fraud", count: 56 + seed, change: 15 + (seed % 6) },
          { category: "Other IPC Offences", count: 26 + (seed % 8), change: -2 + (seed % 3) },
        ];

  const crimeRate = totalThisMonth / populationLakh;
  const safetyScore = Math.max(30, Math.min(100, Math.round(100 - crimeRate * 0.7)));
  const safetyGrade = safetyScore >= 75 ? "Safe" : safetyScore >= 55 ? "Moderate" : "Risky";

  const trafficViolations = (slug === "krishna" ? 7180 : 8240) + seed * 80;
  const trafficRevenue = trafficViolations * 850 + seed * 12000;

  const data = {
    safetyScore,
    safetyGrade,
    stations,
    crimeStats: {
      totalThisMonth,
      totalLastMonth: totalThisMonth + 35 - seed * 2,
      categories,
    },
    trafficData: {
      violationsThisMonth: trafficViolations,
      revenueCollected: trafficRevenue,
      majorViolation: month >= 3 && month <= 5 ? "Drunk driving" : "Over-speeding",
    },
    lastUpdated: now.toISOString(),
  };

  cache.set(cacheKey, data, 30 * 60 * 1000);
  return res.json(data);
});

export default router;
