import {
  useGetHealthEmergency,
  getGetHealthEmergencyQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, MapPin, Activity, Shield, Heart, ExternalLink } from "lucide-react";
import { openUrl } from "@/lib/open-url";
import { DataSource } from "@/components/data-source";
import { useDistrict } from "@/contexts/district-context";

export default function Health() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetHealthEmergency(params, {
    query: { queryKey: getGetHealthEmergencyQueryKey(params) },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING HEALTH DATA...
      </div>
    );
  }

  const fmt = (n: number) => n >= 100000 ? `${(n / 100000).toFixed(1)}L` : n >= 1000 ? `${(n / 1000).toFixed(1)}K` : `${n}`;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold uppercase tracking-widest text-foreground">
          Health & Emergency
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Emergency contacts, government hospitals, and health schemes for Guntur District.
        </p>
      </div>

      {/* Emergency contacts — big call-to-action style */}
      <div>
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">Emergency Contacts</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {(data?.emergencyContacts ?? []).slice(0, 4).map((c) => (
            <div
              key={c.number}
              className="rounded-xl border bg-red-500/5 border-red-500/20 p-4 text-center"
            >
              <p className="text-3xl font-bold font-mono text-red-400">{c.number}</p>
              <p className="text-sm font-semibold mt-1">{c.name}</p>
              <p className="text-[11px] text-muted-foreground mt-1">{c.available}</p>
            </div>
          ))}
        </div>

        {/* Secondary emergency contacts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
          {(data?.emergencyContacts ?? []).slice(4).map((c) => (
            <div
              key={c.number}
              className="rounded-lg border bg-card border-border/50 p-3 flex items-center gap-3"
            >
              <Phone className="w-4 h-4 text-primary shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold">{c.name}</p>
                <p className="text-[11px] text-muted-foreground truncate">{c.description}</p>
              </div>
              <p className="text-base font-bold font-mono text-primary shrink-0">{c.number}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Government Hospitals */}
      <div>
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">Government Hospitals</p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {(data?.hospitals ?? []).map((h) => (
            <Card key={h.id} className="bg-card border-border/50">
              <CardContent className="p-4">
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold text-sm leading-snug">{h.name}</h3>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{h.type}</p>
                  </div>
                  {h.emergencyAvailable && (
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded border text-red-400 bg-red-500/10 border-red-500/30 shrink-0">
                      24/7 Emergency
                    </span>
                  )}
                </div>

                <div className="space-y-1.5 text-xs text-muted-foreground mb-3">
                  <p className="flex items-start gap-1.5">
                    <MapPin className="w-3 h-3 mt-0.5 shrink-0" />
                    {h.address}
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3 h-3 shrink-0" />
                    {h.phone}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
                  <div className="bg-background/50 rounded p-2 border border-border/40">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Total Beds</p>
                    <p className="font-bold font-mono text-foreground">{h.beds}</p>
                  </div>
                  <div className="bg-background/50 rounded p-2 border border-border/40">
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">ICU Beds</p>
                    <p className="font-bold font-mono text-cyan-400">{h.icuBeds}</p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1 mb-3">
                  {h.services.slice(0, 4).map((s) => (
                    <span key={s} className="text-[10px] px-2 py-0.5 bg-primary/10 text-primary rounded border border-primary/20">
                      {s}
                    </span>
                  ))}
                  {h.services.length > 4 && (
                    <span className="text-[10px] px-2 py-0.5 bg-muted text-muted-foreground rounded border border-border/40">
                      +{h.services.length - 4} more
                    </span>
                  )}
                </div>

                <button
                  onClick={() => h.mapUrl && openUrl(h.mapUrl)}
                  className="flex items-center gap-1 text-[11px] font-mono text-primary hover:text-primary/80 transition-colors"
                >
                  <MapPin className="w-3 h-3" />
                  View on Map
                </button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Health Schemes */}
      <div>
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">Government Health Schemes</p>
        <div className="space-y-4 pb-2">
          {(data?.healthSchemes ?? []).map((scheme) => (
            <Card key={scheme.id} className="bg-card border-border/50">
              <CardContent className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-2 mb-3">
                  <div>
                    <h3 className="font-semibold text-sm">{scheme.name}</h3>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{scheme.authority}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded border text-emerald-400 bg-emerald-500/10 border-emerald-500/30">
                      Active
                    </span>
                    <span className="text-sm font-bold font-mono text-cyan-400">{scheme.coverageAmount}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3 text-xs">
                  <div className="bg-background/50 rounded-lg p-3 border border-border/40">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Eligibility</p>
                    <p className="text-foreground leading-relaxed">{scheme.eligibility}</p>
                  </div>
                  <div className="bg-background/50 rounded-lg p-3 border border-border/40">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Benefits</p>
                    <p className="text-foreground leading-relaxed">{scheme.benefits}</p>
                  </div>
                  <div className="bg-background/50 rounded-lg p-3 border border-border/40">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground mb-1">Beneficiaries (District)</p>
                    <p className="text-2xl font-bold font-mono text-emerald-400">{fmt(scheme.beneficiaries)}</p>
                    <p className="text-muted-foreground text-[10px] mt-1">enrolled in Guntur</p>
                  </div>
                </div>

                {scheme.applyUrl && (
                  <button
                    onClick={() => openUrl(scheme.applyUrl!)}
                    className="flex items-center gap-1.5 text-[11px] font-mono text-primary hover:text-primary/80 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    Apply / Know More
                  </button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <DataSource
        sources={[
          { name: "Guntur District Health & FW Dept", note: "Hospital directory" },
          { name: "Dr. YSR Aarogyasri Trust", url: "https://www.ysraarogyasri.ap.gov.in", note: "Aarogyasri scheme" },
          { name: "National Health Authority", url: "https://pmjay.gov.in", note: "Ayushman Bharat / PMJAY" },
          { name: "National Health Mission (NHM)", url: "https://nhm.gov.in", note: "JSY, free medicines" },
          { name: "NDMA", url: "https://ndma.gov.in", note: "Emergency helpline numbers" },
        ]}
      />
    </div>
  );
}
