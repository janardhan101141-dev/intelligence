import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const tod = (h: number, min: number = 0) => {
  const ampm = h >= 12 ? "PM" : "AM";
  const displayH = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return `${displayH}:${String(min).padStart(2, "0")} ${ampm}`;
};

router.get("/power", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `power-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const now = new Date();
  const hour = now.getHours();
  const dayOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
  const isSummer = now.getMonth() >= 3 && now.getMonth() <= 5;
  const isPeakHour = (hour >= 9 && hour <= 13) || (hour >= 18 && hour <= 22);

  const summerBase = slug === "krishna" ? 2620 : 2850;
  const normalBase = slug === "krishna" ? 1980 : 2100;
  const baseDemand = isSummer ? summerBase : normalBase;
  const peakFactor = isPeakHour ? 1.18 : 0.92;
  const demand = Math.round(baseDemand * peakFactor + (dayOfYear % 15) * 8);
  const supplyBase = (isSummer ? summerBase : normalBase) * 0.93;
  const supply = Math.round(supplyBase * peakFactor + (dayOfYear % 12) * 6);
  const deficit = Math.max(0, demand - supply);

  const outages =
    slug === "krishna"
      ? [
          {
            id: "kr-pow-001",
            area: "Gudivada Division",
            type: "scheduled",
            startTime: tod(9),
            endTime: tod(13),
            reason: "Substation maintenance — feeder line 2 inspection",
            affectedHouseholds: 3600,
            status: hour >= 9 && hour < 13 ? "active" : hour < 9 ? "upcoming" : "resolved",
          },
          {
            id: "kr-pow-002",
            area: "Tiruvuru (Rural Feeders)",
            type: "scheduled",
            startTime: tod(14),
            endTime: tod(17),
            reason: "Transformer replacement — 33/11 KV substation upgrade",
            affectedHouseholds: 2200,
            status: hour >= 14 && hour < 17 ? "active" : hour < 14 ? "upcoming" : "resolved",
          },
          {
            id: "kr-pow-003",
            area: "Avanigadda Coastal Zone",
            type: "scheduled",
            startTime: tod(6, 30),
            endTime: tod(9),
            reason: "New aquaculture feeder line extension work",
            affectedHouseholds: 1420,
            status: hour >= 9 ? "resolved" : "upcoming",
          },
          ...(isSummer && isPeakHour
            ? [
                {
                  id: "kr-pow-004",
                  area: "Jaggayyapeta Industrial Area",
                  type: "unscheduled",
                  startTime: tod(hour - 1),
                  endTime: tod(hour + 1),
                  reason: "Grid overload — demand exceeds feeder capacity during peak hours",
                  affectedHouseholds: 2600,
                  status: "active",
                },
              ]
            : []),
          {
            id: "kr-pow-005",
            area: "Nuzvid Agricultural Pumping",
            type: "scheduled",
            startTime: tod(22),
            endTime: tod(6),
            reason: "Scheduled agricultural non-supply period (10 PM – 6 AM)",
            affectedHouseholds: 4700,
            status: hour >= 22 || hour < 6 ? "active" : "upcoming",
          },
        ]
      : [
          {
            id: "pow-001",
            area: "Narasaraopet Division",
            type: "scheduled",
            startTime: tod(9),
            endTime: tod(13),
            reason: "Substation maintenance — feeder line 3 inspection",
            affectedHouseholds: 4200,
            status: hour >= 9 && hour < 13 ? "active" : hour < 9 ? "upcoming" : "resolved",
          },
          {
            id: "pow-002",
            area: "Sattenapalle (Rural Feeders)",
            type: "scheduled",
            startTime: tod(14),
            endTime: tod(17),
            reason: "Transformer replacement — 33/11 KV substation upgrade",
            affectedHouseholds: 2800,
            status: hour >= 14 && hour < 17 ? "active" : hour < 14 ? "upcoming" : "resolved",
          },
          {
            id: "pow-003",
            area: "Repalle Coastal Zone",
            type: "scheduled",
            startTime: tod(6, 30),
            endTime: tod(9),
            reason: "New industrial feeder line extension work",
            affectedHouseholds: 1650,
            status: hour >= 9 ? "resolved" : "upcoming",
          },
          ...(isSummer && isPeakHour
            ? [
                {
                  id: "pow-004",
                  area: "Mangalagiri Industrial Area",
                  type: "unscheduled",
                  startTime: tod(hour - 1),
                  endTime: tod(hour + 1),
                  reason: "Grid overload — demand exceeds feeder capacity during peak hours",
                  affectedHouseholds: 3100,
                  status: "active",
                },
              ]
            : []),
          {
            id: "pow-005",
            area: "Tenali Agricultural Pumping",
            type: "scheduled",
            startTime: tod(22),
            endTime: tod(6),
            reason: "Scheduled agricultural non-supply period (10 PM – 6 AM)",
            affectedHouseholds: 5400,
            status: hour >= 22 || hour < 6 ? "active" : "upcoming",
          },
        ];

  const activeOutages = outages.filter((o) => o.status === "active");
  const overallStatus = activeOutages.length === 0 ? "stable" : deficit > 200 ? "major_outage" : "partial_outage";

  const data = {
    overallStatus,
    demand,
    supply,
    deficit,
    activeOutages: activeOutages.length,
    affectedHouseholds: activeOutages.reduce((s, o) => s + o.affectedHouseholds, 0),
    outages,
    lastUpdated: now.toISOString(),
  };

  cache.set(cacheKey, data, 10 * 60 * 1000);
  return res.json(data);
});

export default router;
