import { useGetDemographics, getGetDemographicsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { DataSource } from "@/components/data-source";
import { Users, GraduationCap, Briefcase, TrendingUp, Building2, Trees } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const SECTOR_COLORS = ["#06b6d4", "#22d3ee", "#67e8f9", "#a5f3fc", "#cffafe"];
const AGE_COLORS = ["#0ea5e9", "#38bdf8", "#7dd3fc", "#bae6fd", "#e0f2fe"];

export default function Demographics() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetDemographics(params, { query: { queryKey: getGetDemographicsQueryKey(params) } });

  if (isLoading || !data) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING DEMOGRAPHICS...
      </div>
    );
  }

  const malePercent = (data.male / data.totalPopulation) * 100;
  const femalePercent = (data.female / data.totalPopulation) * 100;

  return (
    <div className="space-y-6">
      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <Users className="w-3.5 h-3.5" /> Population
            </div>
            <p className="text-2xl font-bold text-primary font-mono">
              {(data.totalPopulation / 1e6).toFixed(2)}M
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">{data.totalPopulation.toLocaleString("en-IN")}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <GraduationCap className="w-3.5 h-3.5" /> Literacy
            </div>
            <p className="text-2xl font-bold text-emerald-400 font-mono">{data.literacyRate}%</p>
            <p className="text-[11px] text-muted-foreground mt-1">M {data.maleLiteracy}% · F {data.femaleLiteracy}%</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <Briefcase className="w-3.5 h-3.5" /> Employed
            </div>
            <p className="text-2xl font-bold text-cyan-400 font-mono">{data.employment.workforceParticipation}%</p>
            <p className="text-[11px] text-muted-foreground mt-1">{(data.employment.employed / 1e6).toFixed(2)}M workers</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground mb-2">
              <TrendingUp className="w-3.5 h-3.5" /> Sex Ratio
            </div>
            <p className="text-2xl font-bold text-fuchsia-400 font-mono">{data.sexRatio}</p>
            <p className="text-[11px] text-muted-foreground mt-1">females per 1,000 males</p>
          </CardContent>
        </Card>
      </div>

      {/* Sex Ratio + Urban/Rural */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest">Gender Distribution</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-cyan-300">Male — {(data.male / 1e6).toFixed(2)}M</span>
                <span className="text-muted-foreground">{malePercent.toFixed(1)}%</span>
              </div>
              <div className="h-3 rounded-full bg-background overflow-hidden">
                <div className="h-full bg-cyan-400" style={{ width: `${malePercent}%` }} />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-xs font-mono mb-1">
                <span className="text-fuchsia-300">Female — {(data.female / 1e6).toFixed(2)}M</span>
                <span className="text-muted-foreground">{femalePercent.toFixed(1)}%</span>
              </div>
              <div className="h-3 rounded-full bg-background overflow-hidden">
                <div className="h-full bg-fuchsia-400" style={{ width: `${femalePercent}%` }} />
              </div>
            </div>
            <div className="pt-2 grid grid-cols-2 gap-2">
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Male Literacy</p>
                <p className="text-lg font-bold text-cyan-300 font-mono">{data.maleLiteracy}%</p>
              </div>
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Female Literacy</p>
                <p className="text-lg font-bold text-fuchsia-300 font-mono">{data.femaleLiteracy}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-mono uppercase tracking-widest">Urban vs Rural</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="rounded-lg border border-cyan-500/30 bg-cyan-500/5 p-4">
                <Building2 className="w-4 h-4 text-cyan-400 mb-2" />
                <p className="text-2xl font-bold text-cyan-300 font-mono">{data.urbanPercent}%</p>
                <p className="text-[11px] text-muted-foreground mt-1">Urban</p>
              </div>
              <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/5 p-4">
                <Trees className="w-4 h-4 text-emerald-400 mb-2" />
                <p className="text-2xl font-bold text-emerald-300 font-mono">{data.ruralPercent}%</p>
                <p className="text-[11px] text-muted-foreground mt-1">Rural</p>
              </div>
            </div>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={data.ageGroups}
                    dataKey="percent"
                    nameKey="group"
                    cx="50%"
                    cy="50%"
                    innerRadius={36}
                    outerRadius={68}
                    paddingAngle={2}
                  >
                    {data.ageGroups.map((_, i) => (
                      <Cell key={i} fill={AGE_COLORS[i % AGE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground/70 text-center mt-1">
              Age Distribution
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Population Trend */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Population Growth — Decadal Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.populationTrend} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
                <defs>
                  <linearGradient id="popGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} />
                <XAxis dataKey="year" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} />
                <YAxis
                  tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }}
                  tickFormatter={(v) => `${(v / 1e6).toFixed(1)}M`}
                />
                <Tooltip
                  contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                  formatter={(v: number) => [`${(v / 1e6).toFixed(2)}M`, "Population"]}
                />
                <Area type="monotone" dataKey="population" stroke="#06b6d4" fill="url(#popGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Employment Sectors */}
      <Card className="bg-card border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm font-mono uppercase tracking-widest">Employment by Sector</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.employment.sectors} layout="vertical" margin={{ left: 8, right: 16 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.4} horizontal={false} />
                  <XAxis type="number" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} unit="%" />
                  <YAxis type="category" dataKey="sector" tick={{ fontSize: 11, fill: "hsl(var(--muted-foreground))" }} width={110} />
                  <Tooltip
                    contentStyle={{ background: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 12 }}
                    formatter={(v: number) => [`${v}%`, "Share"]}
                  />
                  <Bar dataKey="percent" radius={[0, 4, 4, 0]}>
                    {data.employment.sectors.map((_, i) => (
                      <Cell key={i} fill={SECTOR_COLORS[i % SECTOR_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="space-y-3">
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Workforce Participation</p>
                <p className="text-xl font-bold text-cyan-300 font-mono">{data.employment.workforceParticipation}%</p>
                <Progress value={data.employment.workforceParticipation} className="h-1.5 mt-2" />
              </div>
              <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Unemployment Rate</p>
                <p className="text-xl font-bold text-amber-300 font-mono">{data.employment.unemploymentRate}%</p>
                <Progress value={data.employment.unemploymentRate * 5} className="h-1.5 mt-2" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                  <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Employed</p>
                  <p className="text-base font-bold text-emerald-300 font-mono">{(data.employment.employed / 1e6).toFixed(2)}M</p>
                </div>
                <div className="rounded-lg bg-background/50 border border-border/40 p-3">
                  <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Unemployed</p>
                  <p className="text-base font-bold text-amber-300 font-mono">{(data.employment.unemployed / 1e3).toFixed(0)}K</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <DataSource
        lastUpdated={data.lastUpdated}
        sources={[
          { name: "Census of India", url: "https://censusindia.gov.in", note: "2011 baseline + projections" },
          { name: "AP Bureau of Economics & Statistics", url: "https://core.ap.gov.in", note: "Sex ratio & literacy" },
          { name: "Periodic Labour Force Survey (PLFS)", url: "https://mospi.gov.in", note: "Employment data" },
        ]}
      />
    </div>
  );
}
