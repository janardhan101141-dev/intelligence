import {
  useGetHousingSchemes,
  getGetHousingSchemesQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Home, CheckCircle, Hammer, Clock, Users } from "lucide-react";
import { DataSource } from "@/components/data-source";
import { useDistrict } from "@/contexts/district-context";

const typeColors: Record<string, string> = {
  Central: "text-blue-400 bg-blue-500/10 border-blue-500/30",
  State: "text-purple-400 bg-purple-500/10 border-purple-500/30",
};

export default function Housing() {
  const { district } = useDistrict();
  const params = { district };
  const { data, isLoading } = useGetHousingSchemes(params, {
    query: { queryKey: getGetHousingSchemesQueryKey(params) },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground font-mono text-sm tracking-widest animate-pulse">
        LOADING HOUSING DATA...
      </div>
    );
  }

  const totals = (data ?? []).reduce(
    (acc, s) => ({
      sanctioned: acc.sanctioned + s.sanctioned,
      completed: acc.completed + s.completed,
      underConstruction: acc.underConstruction + s.underConstruction,
      pending: acc.pending + s.pendingApprovals,
      beneficiaries: acc.beneficiaries + s.beneficiaries,
    }),
    { sanctioned: 0, completed: 0, underConstruction: 0, pending: 0, beneficiaries: 0 }
  );

  const fmt = (n: number) =>
    n >= 100000 ? `${(n / 100000).toFixed(1)}L` : n >= 1000 ? `${(n / 1000).toFixed(1)}K` : `${n}`;

  const fmtCr = (n: number) => `Rs ${(n / 10000000).toFixed(0)} Cr`;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-mono font-bold uppercase tracking-widest text-foreground">
          Housing Schemes
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Government housing programme progress — PMAY, YSR Colonies, and state schemes in Guntur District.
        </p>
      </div>

      {/* District summary totals */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {[
          { label: "Total Sanctioned", value: fmt(totals.sanctioned), icon: Home, color: "text-primary" },
          { label: "Completed", value: fmt(totals.completed), icon: CheckCircle, color: "text-emerald-400" },
          { label: "Under Construction", value: fmt(totals.underConstruction), icon: Hammer, color: "text-amber-400" },
          { label: "Pending Approvals", value: fmt(totals.pending), icon: Clock, color: "text-orange-400" },
          { label: "Total Beneficiaries", value: fmt(totals.beneficiaries), icon: Users, color: "text-cyan-400" },
        ].map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.label} className="bg-card border-border/50">
              <CardContent className="p-4">
                <Icon className={`w-5 h-5 ${s.color} mb-2`} />
                <p className={`text-2xl font-bold font-mono ${s.color}`}>{s.value}</p>
                <p className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground mt-1">{s.label}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Overall progress bar */}
      <Card className="bg-card border-border/50">
        <CardContent className="p-5">
          <div className="flex justify-between items-baseline mb-2">
            <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Overall District Completion</p>
            <p className="text-lg font-bold font-mono text-emerald-400">
              {totals.sanctioned > 0 ? ((totals.completed / totals.sanctioned) * 100).toFixed(1) : 0}%
            </p>
          </div>
          <Progress value={totals.sanctioned > 0 ? (totals.completed / totals.sanctioned) * 100 : 0} className="h-3" />
          <div className="flex gap-4 mt-3 text-xs font-mono text-muted-foreground">
            <span className="text-emerald-400">Completed: {fmt(totals.completed)}</span>
            <span className="text-amber-400">In Progress: {fmt(totals.underConstruction)}</span>
            <span className="text-orange-400">Pending: {fmt(totals.pending)}</span>
          </div>
        </CardContent>
      </Card>

      {/* Scheme cards */}
      <div className="space-y-4 pb-2">
        {(data ?? []).map((scheme) => (
          <Card key={scheme.id} className="bg-card border-border/50">
            <CardContent className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-2 mb-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-semibold text-base">{scheme.name}</h3>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border ${typeColors[scheme.type] ?? "text-muted-foreground border-border"}`}
                    >
                      {scheme.type}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                        scheme.status === "active"
                          ? "text-emerald-400 bg-emerald-500/10 border-emerald-500/30"
                          : "text-cyan-400 bg-cyan-500/10 border-cyan-500/30"
                      }`}
                    >
                      {scheme.status === "near-complete" ? "Near Complete" : "Active"}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{scheme.description}</p>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mb-4">
                <div className="flex justify-between mb-1 text-xs font-mono">
                  <span className="text-muted-foreground">Completion Progress</span>
                  <span className="text-emerald-400">{scheme.completionPercent}%</span>
                </div>
                <div className="h-3 bg-background rounded-full overflow-hidden border border-border/50">
                  <div
                    className="h-full bg-emerald-500 transition-all duration-700"
                    style={{ width: `${scheme.completionPercent}%` }}
                  />
                </div>
              </div>

              {/* Stats grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {[
                  { label: "Sanctioned", value: fmt(scheme.sanctioned), color: "text-foreground" },
                  { label: "Completed", value: fmt(scheme.completed), color: "text-emerald-400" },
                  { label: "Under Construction", value: fmt(scheme.underConstruction), color: "text-amber-400" },
                  { label: "Pending Approvals", value: fmt(scheme.pendingApprovals), color: "text-orange-400" },
                  { label: "Beneficiaries", value: fmt(scheme.beneficiaries), color: "text-cyan-400" },
                  { label: "Allotted", value: fmt(scheme.allotted), color: "text-primary" },
                  { label: "Budget", value: fmtCr(scheme.budget), color: "text-muted-foreground" },
                  { label: "Spent", value: fmtCr(scheme.spentBudget), color: "text-muted-foreground" },
                ].map((stat) => (
                  <div key={stat.label} className="bg-background/50 rounded-lg p-3 border border-border/50">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">{stat.label}</p>
                    <p className={`text-base font-bold font-mono ${stat.color}`}>{stat.value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <DataSource
        sources={[
          { name: "Ministry of Rural Development (PMAY-G)", url: "https://pmayg.nic.in", note: "PMAY-G data" },
          { name: "Ministry of Housing & Urban Affairs", url: "https://pmay-urban.gov.in", note: "PMAY-U data" },
          { name: "AP Housing Corporation", url: "https://aphousing.ap.gov.in", note: "State schemes" },
          { name: "Guntur District Collector Office", note: "YSR Colonies & local data" },
        ]}
      />
    </div>
  );
}
