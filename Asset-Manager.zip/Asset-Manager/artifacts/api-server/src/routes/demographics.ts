import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const DISTRICT_DATA: Record<
  string,
  {
    totalPopulation: number;
    male: number;
    literacyRate: number;
    maleLiteracy: number;
    femaleLiteracy: number;
    urbanPercent: number;
    populationTrend: { year: number; population: number }[];
    ageGroups: { group: string; percent: number }[];
    workforceParticipation: number;
    unemploymentRate: number;
    sectors: { sector: string; percent: number }[];
  }
> = {
  guntur: {
    totalPopulation: 5823000,
    male: 2895000,
    literacyRate: 67.4,
    maleLiteracy: 75.1,
    femaleLiteracy: 59.5,
    urbanPercent: 33.8,
    populationTrend: [
      { year: 1991, population: 4145000 },
      { year: 2001, population: 4889000 },
      { year: 2011, population: 4887000 },
      { year: 2021, population: 5563000 },
      { year: 2024, population: 5780000 },
      { year: 2026, population: 5823000 },
    ],
    ageGroups: [
      { group: "0-14", percent: 24.6 },
      { group: "15-29", percent: 26.8 },
      { group: "30-44", percent: 22.1 },
      { group: "45-59", percent: 15.4 },
      { group: "60+", percent: 11.1 },
    ],
    workforceParticipation: 47.2,
    unemploymentRate: 6.8,
    sectors: [
      { sector: "Agriculture", percent: 42.5 },
      { sector: "Services", percent: 28.7 },
      { sector: "Manufacturing", percent: 14.2 },
      { sector: "Construction", percent: 9.8 },
      { sector: "Government", percent: 4.8 },
    ],
  },
  krishna: {
    totalPopulation: 4517000,
    male: 2247000,
    literacyRate: 73.8,
    maleLiteracy: 80.2,
    femaleLiteracy: 67.4,
    urbanPercent: 43.2,
    populationTrend: [
      { year: 1991, population: 3486000 },
      { year: 2001, population: 4187000 },
      { year: 2011, population: 4517000 },
      { year: 2021, population: 4498000 },
      { year: 2024, population: 4510000 },
      { year: 2026, population: 4517000 },
    ],
    ageGroups: [
      { group: "0-14", percent: 22.4 },
      { group: "15-29", percent: 25.9 },
      { group: "30-44", percent: 23.6 },
      { group: "45-59", percent: 16.8 },
      { group: "60+", percent: 11.3 },
    ],
    workforceParticipation: 49.6,
    unemploymentRate: 5.9,
    sectors: [
      { sector: "Agriculture", percent: 34.2 },
      { sector: "Services", percent: 34.8 },
      { sector: "Manufacturing", percent: 16.4 },
      { sector: "Trade & Commerce", percent: 9.2 },
      { sector: "Government", percent: 5.4 },
    ],
  },
};

router.get("/demographics", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `demographics-${slug}`;
  const cached = cache.get<object>(cacheKey);
  if (cached) return res.json(cached);

  const d = DISTRICT_DATA[slug];
  const female = d.totalPopulation - d.male;
  const sexRatio = Math.round((female / d.male) * 1000);
  const employed = Math.round(d.totalPopulation * (d.workforceParticipation / 100) * (1 - d.unemploymentRate / 100));
  const unemployed = Math.round(d.totalPopulation * (d.workforceParticipation / 100) * (d.unemploymentRate / 100));

  const data = {
    totalPopulation: d.totalPopulation,
    male: d.male,
    female,
    sexRatio,
    literacyRate: d.literacyRate,
    maleLiteracy: d.maleLiteracy,
    femaleLiteracy: d.femaleLiteracy,
    urbanPercent: d.urbanPercent,
    ruralPercent: parseFloat((100 - d.urbanPercent).toFixed(1)),
    populationTrend: d.populationTrend,
    ageGroups: d.ageGroups,
    employment: {
      workforceParticipation: d.workforceParticipation,
      unemploymentRate: d.unemploymentRate,
      employed,
      unemployed,
      sectors: d.sectors,
    },
    lastUpdated: new Date().toISOString(),
  };

  cache.set(cacheKey, data, 60 * 60 * 1000);
  return res.json(data);
});

export default router;
