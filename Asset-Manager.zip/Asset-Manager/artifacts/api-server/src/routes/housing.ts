import { Router } from "express";
import { cache } from "../lib/cache";
import { resolveDistrict } from "../lib/district";

const router = Router();

const DISTRICT_HOUSING_BASE: Record<
  string,
  { sanctioned: [number, number, number, number, number]; budget: [number, number, number, number, number] }
> = {
  guntur: {
    sanctioned: [148200, 42800, 68000, 28400, 19600],
    budget: [22300000000, 8900000000, 12400000000, 5100000000, 3200000000],
  },
  krishna: {
    sanctioned: [126400, 51200, 58600, 22800, 16400],
    budget: [19100000000, 10600000000, 10800000000, 4300000000, 2700000000],
  },
};

router.get("/housing", (req, res) => {
  const slug = resolveDistrict(req);
  const cacheKey = `housing-${slug}`;
  const cached = cache.get<object[]>(cacheKey);
  if (cached) return res.json(cached);

  const [s1, s2, s3, s4, s5] = DISTRICT_HOUSING_BASE[slug].sanctioned;
  const [b1, b2, b3, b4, b5] = DISTRICT_HOUSING_BASE[slug].budget;

  const now = new Date();
  const dayOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
  const progress = dayOfYear / 365;

  const schemes = [
    {
      id: "hs-001",
      name: "Pradhan Mantri Awas Yojana – Gramin",
      shortName: "PMAY-G",
      type: "Central",
      sanctioned: s1,
      completed: Math.round(s1 * (0.68 + progress * 0.08)),
      underConstruction: Math.round(s1 * (0.18 - progress * 0.04)),
      pendingApprovals: Math.max(200, Math.round(s1 * (0.08 - progress * 0.02))),
      beneficiaries: s1,
      allotted: s1,
      budget: b1,
      spentBudget: Math.round(b1 * (0.72 + progress * 0.1)),
      completionPercent: parseFloat((68 + progress * 8).toFixed(1)),
      status: "active",
      description: "Central government scheme providing financial assistance of Rs 1.20 lakh per house in plain areas to BPL rural households.",
    },
    {
      id: "hs-002",
      name: "Pradhan Mantri Awas Yojana – Urban",
      shortName: "PMAY-U",
      type: "Central",
      sanctioned: s2,
      completed: Math.round(s2 * (0.61 + progress * 0.06)),
      underConstruction: Math.round(s2 * (0.22 - progress * 0.03)),
      pendingApprovals: Math.max(150, Math.round(s2 * (0.09 - progress * 0.02))),
      beneficiaries: s2,
      allotted: s2,
      budget: b2,
      spentBudget: Math.round(b2 * (0.65 + progress * 0.08)),
      completionPercent: parseFloat((61 + progress * 6).toFixed(1)),
      status: "active",
      description: "Urban housing for all — provides subsidy under Credit Linked Subsidy Scheme (CLSS) for EWS/LIG/MIG categories.",
    },
    {
      id: "hs-003",
      name: "YSR Jagananna Colonies",
      shortName: "YSR Colonies",
      type: "State",
      sanctioned: s3,
      completed: Math.round(s3 * (0.79 + progress * 0.05)),
      underConstruction: Math.round(s3 * (0.14 - progress * 0.03)),
      pendingApprovals: Math.max(50, Math.round(s3 * (0.04 - progress * 0.01))),
      beneficiaries: s3,
      allotted: s3,
      budget: b3,
      spentBudget: Math.round(b3 * (0.81 + progress * 0.07)),
      completionPercent: parseFloat((79 + progress * 5).toFixed(1)),
      status: "active",
      description: "AP state government scheme providing free house sites with basic amenities to economically weaker sections of society.",
    },
    {
      id: "hs-004",
      name: "Weaker Section Housing",
      shortName: "WSH",
      type: "State",
      sanctioned: s4,
      completed: Math.round(s4 * (0.54 + progress * 0.1)),
      underConstruction: Math.round(s4 * (0.28 - progress * 0.05)),
      pendingApprovals: Math.max(100, Math.round(s4 * (0.12 - progress * 0.03))),
      beneficiaries: s4,
      allotted: Math.round(s4 * 0.98),
      budget: b4,
      spentBudget: Math.round(b4 * (0.58 + progress * 0.12)),
      completionPercent: parseFloat((54 + progress * 10).toFixed(1)),
      status: "active",
      description: "State scheme for SC/ST and other weaker sections providing housing with sanitation and drinking water facilities.",
    },
    {
      id: "hs-005",
      name: "NTR Housing Scheme",
      shortName: "NTR Housing",
      type: "State",
      sanctioned: s5,
      completed: Math.round(s5 * (0.88 + progress * 0.03)),
      underConstruction: Math.round(s5 * (0.07 - progress * 0.02)),
      pendingApprovals: Math.max(20, Math.round(s5 * (0.02 - progress * 0.005))),
      beneficiaries: s5,
      allotted: s5,
      budget: b5,
      spentBudget: Math.round(b5 * (0.9 + progress * 0.05)),
      completionPercent: parseFloat((88 + progress * 3).toFixed(1)),
      status: "near-complete",
      description: "Legacy AP housing scheme for rural and semi-urban poor providing pucca houses with 2 rooms, kitchen, and toilet.",
    },
  ];

  cache.set(cacheKey, schemes, 30 * 60 * 1000);
  return res.json(schemes);
});

export default router;
