import { Router } from "express";
import { resolveDistrict } from "../lib/district";

const router = Router();

const DISTRICT_CONFIG: Record<
  string,
  {
    totalBudget: number;
    revenueBase: number;
    policeStations: number;
    hospitals: number;
    schools: number;
    panchayats: number;
    activeSchemes: number;
  }
> = {
  guntur: {
    totalBudget: 8500000000,
    revenueBase: 3200000000,
    policeStations: 52,
    hospitals: 38,
    schools: 1847,
    panchayats: 673,
    activeSchemes: 24,
  },
  krishna: {
    totalBudget: 7900000000,
    revenueBase: 3450000000,
    policeStations: 46,
    hospitals: 41,
    schools: 1620,
    panchayats: 588,
    activeSchemes: 22,
  },
};

router.get("/governance", (req, res) => {
  const slug = resolveDistrict(req);
  const cfg = DISTRICT_CONFIG[slug];
  const now = new Date();
  const dayOfYear = Math.floor((now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000);
  const yearProgress = dayOfYear / 365;

  const baseSpending = cfg.totalBudget * 0.55;
  const dynamicSpending = baseSpending + cfg.totalBudget * yearProgress * 0.25;
  const spending = Math.round(Math.min(dynamicSpending, cfg.totalBudget * 0.91));
  const utilization = parseFloat(((spending / cfg.totalBudget) * 100).toFixed(1));

  return res.json({
    totalBudget: cfg.totalBudget,
    spending,
    utilizationPercent: utilization,
    revenue: cfg.revenueBase + Math.round(yearProgress * 800000000),
    policeStations: cfg.policeStations,
    hospitals: cfg.hospitals,
    schools: cfg.schools,
    panchayats: cfg.panchayats,
    activeSchemes: cfg.activeSchemes,
    pendingGrievances: Math.max(800, 1243 - Math.floor(dayOfYear * 0.5)),
    resolvedGrievances: 8765 + Math.floor(dayOfYear * 1.2),
    lastUpdated: new Date().toISOString(),
  });
});

export default router;
