export type DistrictSlug = "guntur" | "krishna";

export function resolveDistrict(req: { query: { district?: unknown } }): DistrictSlug {
  return req.query.district === "krishna" ? "krishna" : "guntur";
}
