import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  Map,
  Briefcase,
  Landmark,
  Newspaper,
  Activity,
  Clock,
  Droplets,
  Home,
  Zap,
  Heart,
  Shield,
  Wind,
  Users,
  FileSearch,
  Construction,
  TrendingUp,
  Trophy,
  Car,
} from "lucide-react";
import { useGetDistrictSummary, getGetDistrictSummaryQueryKey } from "@workspace/api-client-react";
import { useEffect, useState } from "react";
import { useDistrict, DISTRICT_OPTIONS } from "@/contexts/district-context";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const navSections = [
  {
    label: "Overview",
    items: [
      { name: "Dashboard", href: "/", icon: LayoutDashboard },
      { name: "Mandals", href: "/mandals", icon: Map },
      { name: "Demographics", href: "/demographics", icon: Users },
      { name: "Comparison", href: "/comparison", icon: Trophy },
    ],
  },
  {
    label: "Governance",
    items: [
      { name: "Governance", href: "/governance", icon: Landmark },
      { name: "Transparency", href: "/transparency", icon: FileSearch },
      { name: "Economy", href: "/economy", icon: TrendingUp },
    ],
  },
  {
    label: "Infrastructure",
    items: [
      { name: "Projects & Roads", href: "/infrastructure", icon: Construction },
      { name: "Traffic", href: "/traffic", icon: Car },
      { name: "Water Supply", href: "/water", icon: Droplets },
      { name: "Power & Outages", href: "/power", icon: Zap },
      { name: "Air Quality", href: "/aqi", icon: Wind },
    ],
  },
  {
    label: "Public Services",
    items: [
      { name: "Services", href: "/services", icon: Briefcase },
      { name: "Housing Schemes", href: "/housing", icon: Home },
      { name: "Health & Emergency", href: "/health", icon: Heart },
      { name: "Police & Safety", href: "/police", icon: Shield },
    ],
  },
  {
    label: "Economy & Media",
    items: [
      { name: "Mandi Prices", href: "/mandi", icon: Activity },
      { name: "News", href: "/news", icon: Newspaper },
    ],
  },
];

const allNavItems = navSections.flatMap((s) => s.items);

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { district, setDistrict } = useDistrict();
  const params = { district };
  const { data: summary } = useGetDistrictSummary(params, {
    query: { queryKey: getGetDistrictSummaryQueryKey(params) },
  });
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex h-screen w-full bg-background text-foreground dark overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 border-r border-border bg-sidebar flex flex-col">
        <div className="p-5 border-b border-border">
          <h1 className="text-xl font-bold tracking-tight text-primary font-mono uppercase">
            {summary?.districtName || "GUNTUR"} OPS
          </h1>
          <p className="text-xs text-muted-foreground mt-1 tracking-wider uppercase">District Intelligence</p>
          <Select value={district} onValueChange={(value) => setDistrict(value as typeof district)}>
            <SelectTrigger className="mt-3 h-8 text-xs font-mono uppercase tracking-wider" data-testid="select-district">
              <SelectValue placeholder="Select district" />
            </SelectTrigger>
            <SelectContent>
              {DISTRICT_OPTIONS.map((option) => (
                <SelectItem key={option.value} value={option.value} className="text-xs font-mono uppercase tracking-wider">
                  {option.label} District
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <nav className="flex-1 overflow-y-auto py-3">
          {navSections.map((section) => (
            <div key={section.label} className="mb-2">
              <p className="px-4 py-1.5 text-[10px] font-mono uppercase tracking-widest text-muted-foreground/60">
                {section.label}
              </p>
              <ul className="space-y-0.5 px-3">
                {section.items.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className={`flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                        location === item.href
                          ? "bg-primary/10 text-primary"
                          : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                      }`}
                    >
                      <item.icon className="h-4 w-4 shrink-0" />
                      {item.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
        <div className="p-4 border-t border-border mt-auto">
          <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
            </span>
            SYSTEM ONLINE
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-background">
        {/* Header */}
        <header className="h-16 border-b border-border flex items-center justify-between px-6 bg-card flex-shrink-0">
          <div className="flex items-center gap-4">
            <h2 className="text-lg font-semibold tracking-tight text-foreground">
              {allNavItems.find((n) => n.href === location)?.name || "Dashboard"}
            </h2>
            {summary && (
              <div className="hidden md:flex items-center gap-2 text-sm">
                <span className="px-2 py-1 bg-primary/10 text-primary rounded border border-primary/20 font-mono text-xs">
                  SCORE: {summary.healthScore}/100 ({summary.grade})
                </span>
                {summary.criticalAlerts > 0 && (
                  <span className="px-2 py-1 bg-destructive/10 text-destructive rounded border border-destructive/20 font-mono text-xs">
                    CRITICAL ALERTS: {summary.criticalAlerts}
                  </span>
                )}
              </div>
            )}
          </div>
          <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground">
            <Clock className="h-4 w-4" />
            {time.toLocaleTimeString()}
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
