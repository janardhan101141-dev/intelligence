import { useGetNews, getGetNewsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Calendar, Newspaper } from "lucide-react";
import { useDistrict } from "@/contexts/district-context";

export default function News() {
  const { district } = useDistrict();
  const params = { district };
  const { data: news } = useGetNews(params, { query: { queryKey: getGetNewsQueryKey(params) } });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground font-mono uppercase tracking-tight">Intelligence Feed</h1>
          <p className="text-muted-foreground mt-1">Aggregated news and alerts regarding district activities.</p>
        </div>
      </div>

      <div className="space-y-4">
        {news?.map((item) => (
          <Card key={item.id} className="bg-card border-border hover:border-primary/30 transition-colors">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-start gap-4">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <Badge variant="outline" className="font-mono text-xs uppercase bg-accent/20 text-accent-foreground border-accent/30">
                      {item.category}
                    </Badge>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono">
                      <Newspaper className="h-3 w-3" />
                      {item.source}
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-mono">
                      <Calendar className="h-3 w-3" />
                      {new Date(item.publishedAt).toLocaleString()}
                    </div>
                  </div>
                  <h2 className="text-lg font-bold mb-2 leading-tight">{item.headline}</h2>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.summary}</p>
                </div>
                {item.url && (
                  <div className="shrink-0 mt-4 md:mt-0">
                    <a 
                      href={item.url} 
                      target="_blank" 
                      rel="noreferrer"
                      className="inline-flex items-center gap-2 px-4 py-2 bg-sidebar border border-border rounded text-sm font-medium hover:bg-accent hover:text-accent-foreground transition-colors font-mono uppercase"
                    >
                      Source <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
