import { Router } from "express";
import { db } from "@workspace/db";
import { districtsTable, mandalsTable, citizenServicesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

function resolveDistrict(req: { query: { district?: unknown } }): string {
  const d = req.query.district;
  return d === "krishna" ? "krishna" : "guntur";
}

const SUMMARY_BY_DISTRICT: Record<string, { districtName: string; healthScore: number; grade: string; activeAlerts: number; criticalAlerts: number; budgetUtilization: number; topMandiCrop: string; topMandiPrice: number }> = {
  guntur: {
    districtName: "Guntur",
    healthScore: 50.8,
    grade: "C",
    activeAlerts: 4,
    criticalAlerts: 1,
    budgetUtilization: 64.3,
    topMandiCrop: "Chilli",
    topMandiPrice: 18500,
  },
  krishna: {
    districtName: "Krishna",
    healthScore: 58.4,
    grade: "C",
    activeAlerts: 4,
    criticalAlerts: 1,
    budgetUtilization: 68.1,
    topMandiCrop: "Mango",
    topMandiPrice: 6800,
  },
};

router.get("/district", async (req, res) => {
  try {
    const slug = resolveDistrict(req);
    const districts = await db.select().from(districtsTable).where(eq(districtsTable.slug, slug)).limit(1);
    if (districts.length === 0) {
      return res.status(404).json({ error: "District not found" });
    }
    const d = districts[0];
    return res.json({
      name: d.name,
      tagline: d.tagline,
      tags: d.tags,
      population: d.population,
      area: d.area,
      literacy: d.literacy,
      mandals: d.mandals,
      headquarters: d.headquarters,
      established: d.established,
      famousPeople: d.famousPeople,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get district");
    return res.status(500).json({ error: "Internal server error" });
  }
});

const HEALTH_SCORE_METRICS: Record<string, Record<string, number>> = {
  guntur: {
    governance: 52,
    education: 61,
    healthcare: 48,
    infrastructure: 55,
    water: 38,
    economy: 47,
    safety: 58,
    agriculture: 72,
    digital: 34,
    welfare: 43,
  },
  krishna: {
    governance: 58,
    education: 66,
    healthcare: 54,
    infrastructure: 62,
    water: 49,
    economy: 64,
    safety: 55,
    agriculture: 68,
    digital: 47,
    welfare: 49,
  },
};

router.get("/district/health-score", async (req, res) => {
  const slug = resolveDistrict(req);
  const metrics = HEALTH_SCORE_METRICS[slug];
  const overall = parseFloat(
    (Object.values(metrics).reduce((a, b) => a + b, 0) / Object.values(metrics).length).toFixed(2)
  );
  const grade = overall >= 70 ? "A" : overall >= 55 ? "B" : overall >= 40 ? "C" : "D";
  return res.json({
    overall,
    grade,
    metrics,
    lastUpdated: new Date().toISOString(),
  });
});

router.get("/district/mandals", async (req, res) => {
  try {
    const slug = resolveDistrict(req);
    const mandals = await db.select().from(mandalsTable).where(eq(mandalsTable.district, slug));
    return res.json(mandals);
  } catch (err) {
    req.log.error({ err }, "Failed to get mandals");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/district/services", async (req, res) => {
  try {
    const slug = resolveDistrict(req);
    const services = await db.select().from(citizenServicesTable).where(eq(citizenServicesTable.district, slug));
    return res.json(
      services.map((s) => ({
        id: s.id,
        name: s.name,
        category: s.category,
        description: s.description,
        url: s.url ?? undefined,
        icon: s.icon,
        status: s.status,
        phone: s.phone,
        officeHours: s.officeHours,
        applicationsThisMonth: s.applicationsThisMonth,
        pendingApplications: s.pendingApplications,
        avgResponseDays: s.avgResponseDays,
        totalProcessed: s.totalProcessed,
        satisfactionScore: s.satisfactionScore,
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Failed to get services");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/district/summary", async (req, res) => {
  const slug = resolveDistrict(req);
  const base = SUMMARY_BY_DISTRICT[slug];
  try {
    const { fetchLiveWeather } = await import("./weather");
    const weather = (await fetchLiveWeather(slug)) as { temperature: number; condition: string };

    return res.json({
      ...base,
      temperature: weather.temperature,
      weatherCondition: weather.condition,
      lastUpdated: new Date().toISOString(),
    });
  } catch {
    return res.json({
      ...base,
      temperature: slug === "krishna" ? 36 : 38,
      weatherCondition: "Partly Cloudy",
      lastUpdated: new Date().toISOString(),
    });
  }
});

export default router;
